
import pandas as pd

folder = "C:/Users/rhutu/OneDrive/Desktop/DMV practicals/datasets/"
data = pd.read_csv(folder + "Bengaluru_House_Data.csv")
data.columns = data.columns.str.strip().str.lower().str.replace(r"\W+", "_", regex=True)
print(data.head())
print("Missing values:\n", data.isna().sum())

data = data[["location", "area_type", "size", "total_sqft", "bath", "price"]].drop_duplicates()
data["location"] = data["location"].str.strip().str.lower().fillna("unknown")
data["area_type"] = data["area_type"].str.strip().fillna("Unknown")
data["bhk"] = pd.to_numeric(data["size"].str.split().str[0], errors="coerce")

def square_feet(value):
    try:
        numbers = [float(x) for x in str(value).split("-")]
        return sum(numbers) / len(numbers)
    except ValueError:
        return float("nan")

data["total_sqft"] = data["total_sqft"].apply(square_feet)
data["bath"] = data["bath"].fillna(data["bath"].median())
data = data.dropna(subset=["bhk", "total_sqft", "price"])


data = data[data["bhk"].between(1, 5) & (data["price"] > 0)
            & (data["total_sqft"] > 0)].copy()
data["price_per_sqft"] = data["price"] * 100000 / data["total_sqft"]
q1, q3 = data["price_per_sqft"].quantile([0.25, 0.75])
iqr = q3 - q1
keep = data["price_per_sqft"].between(q1 - 1.5 * iqr, q3 + 1.5 * iqr)
print("Price-per-square-foot outliers removed:", (~keep).sum())
data = data[keep]

print("Average price (lakh rupees) by location:")
print(data.groupby("location")["price"].mean().sort_values(ascending=False).head(10))
print("Average price by property type:\n", data.groupby("area_type")["price"].mean())

counts = data["location"].value_counts()
data["location"] = data["location"].where(data["location"].map(counts) > 10, "other")
encoded = pd.get_dummies(data.drop(columns="size"), columns=["location", "area_type"])
print("Prepared data shape:", encoded.shape)

