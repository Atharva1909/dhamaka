
import pandas as pd
import matplotlib.pyplot as plt

folder = "C:/Users/rhutu/OneDrive/Desktop/DMV practicals/datasets/"
data = pd.read_csv(folder + "sales_data_sample.csv", encoding="cp1252")
print(data.head())
data.info()

data = data.rename(columns={"TERRITORY": "Region", "PRODUCTLINE": "Category", "SALES": "Sales"})
data["Region"] = data["Region"].fillna("Unknown").str.strip()
data["Sales"] = pd.to_numeric(data["Sales"], errors="coerce")
data = data.drop_duplicates(subset=["ORDERNUMBER", "ORDERLINENUMBER"])
data = data.dropna(subset=["Sales", "Category"])
data = data[data["Sales"] > 0]

sales = data.groupby("Region")["Sales"].sum().sort_values(ascending=False)
print("Total sales by region:\n", sales.round(2))
print("Top known regions:\n", sales.drop(index="Unknown", errors="ignore").head(3).round(2))
sales.plot.bar(title="Sales by Region")
plt.xlabel("Region")
plt.ylabel("Sales amount")
plt.tight_layout()
plt.show()

combined = data.groupby(["Region", "Category"])["Sales"].sum().unstack(fill_value=0)
print("Sales by region and category:\n", combined.round(2))
combined.plot.bar(stacked=True, figsize=(10, 5), title="Regional Sales by Product Category")
plt.xlabel("Region")
plt.ylabel("Sales amount")
plt.legend(title="Category", bbox_to_anchor=(1, 1))
plt.tight_layout()
plt.show()

