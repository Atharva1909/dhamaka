
from getpass import getpass
import requests
import pandas as pd
import matplotlib.pyplot as plt

api_key = getpass("OpenWeatherMap API key: ")
city = input("City (for example Pune,IN): ").strip() or "Pune,IN"
response = requests.get("https://api.openweathermap.org/data/2.5/forecast",
                        params={"q": city, "appid": api_key, "units": "metric"}, timeout=30)
if response.status_code != 200:
    raise SystemExit("API request failed. Check your key, city, and API access.")
weather = response.json()

rows = []
for item in weather["list"]:
    rows.append({"Time": pd.to_datetime(item["dt"], unit="s", utc=True),
                 "Temperature": item["main"].get("temp"),
                 "Humidity": item["main"].get("humidity"),
                 "Wind": item["wind"].get("speed"),
                 "Rain": item.get("rain", {}).get("3h", 0)})
data = pd.DataFrame(rows).set_index("Time").sort_index()
data.index = data.index + pd.Timedelta(seconds=weather["city"]["timezone"])
data.index = data.index.tz_localize(None)  # City local time.
data = data[~data.index.duplicated()].dropna()
print(data.head())
print("Temperature statistics (C):\n", data["Temperature"].agg(["mean", "min", "max"]))

daily = data.resample("D").agg({"Temperature": "mean", "Humidity": "mean",
                               "Wind": "mean", "Rain": "sum"})
print("Daily forecast summary:\n", daily)
data["Temperature"].plot(title="Temperature Forecast: " + city)
plt.xlabel("Local date and time")
plt.ylabel("Temperature (C)")
plt.tight_layout()
plt.show()
daily["Rain"].plot.bar(title="Daily Forecast Rainfall")
plt.ylabel("Rainfall (mm)")
plt.tight_layout()
plt.show()

print("Weather correlations:\n", data.corr().round(2))
plt.scatter(data["Temperature"], data["Humidity"])
plt.xlabel("Temperature (C)")
plt.ylabel("Humidity (%)")
plt.title("Temperature and Humidity")
plt.show()

location = weather["city"]["coord"]
plt.scatter(location["lon"], location["lat"], s=100)
plt.annotate(city, (location["lon"], location["lat"]))
plt.xlabel("Longitude")
plt.ylabel("Latitude")
plt.title("Forecast Location")
plt.show()

