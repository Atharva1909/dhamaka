
import pandas as pd
import matplotlib.pyplot as plt

folder = "C:/Users/rhutu/OneDrive/Desktop/DMV practicals/datasets/"
data = pd.read_csv(folder + "City_Air_Quality.csv")
print(data.head())
print(data.dtypes)

city = "Delhi"
data = data[data["City"] == city].copy()
data["Date"] = pd.to_datetime(data["Date"], errors="coerce")
data = data.drop_duplicates(subset="Date").dropna(subset=["Date", "AQI"])
data = data.sort_values("Date").set_index("Date")

data["AQI"].plot(title=city + " AQI Over Time", color="red")
plt.xlabel("Date")
plt.ylabel("AQI")
plt.tight_layout()
plt.show()

fig, axes = plt.subplots(3, 1, figsize=(9, 7), sharex=True)
for ax, pollutant, unit in zip(axes, ["PM2.5", "PM10", "CO"], ["ug/m3", "ug/m3", "mg/m3"]):
    ax.plot(data.index, data[pollutant], label=pollutant)
    ax.set_ylabel(unit)
    ax.legend()
fig.suptitle(city + " Pollutant Trends")
plt.xlabel("Date")
plt.tight_layout()
plt.show()

data["AQI"].resample("ME").mean().plot.bar(title="Monthly Average AQI", figsize=(10, 4))
plt.xticks(range(0, len(data.resample("ME")), 6),
           data["AQI"].resample("ME").mean().index.strftime("%Y-%m")[::6], rotation=45)
plt.ylabel("AQI")
plt.tight_layout()
plt.show()

data.boxplot(column="AQI", by="AQI_Bucket", rot=45)
plt.title("AQI Distribution by Air-Quality Category")
plt.suptitle("")
plt.ylabel("AQI")
plt.tight_layout()
plt.show()

plt.scatter(data["PM2.5"], data["AQI"], alpha=0.4)
plt.xlabel("PM2.5 (ug/m3)")
plt.ylabel("AQI")
plt.title("PM2.5 and AQI")
plt.show()

