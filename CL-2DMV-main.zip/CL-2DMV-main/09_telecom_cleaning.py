
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler

folder = "C:/Users/rhutu/OneDrive/Desktop/DMV practicals/datasets/"
data = pd.read_csv(folder + "Telcom_Customer_Churn.csv")
print(data.head())
data.info()
print("Missing values:\n", data.isna().sum())

for column in data.select_dtypes(exclude="number"):
    data[column] = data[column].str.strip().str.lower()
data = data.replace(r"^\s*$", float("nan"), regex=True)
data = data.drop_duplicates(subset="customerID")
for column in ["tenure", "MonthlyCharges", "TotalCharges"]:
    data[column] = pd.to_numeric(data[column], errors="coerce")
data = data.dropna(subset=["Churn"])

train, test = train_test_split(data, test_size=0.2, random_state=42, stratify=data["Churn"])
train, test = train.copy(), test.copy()
numeric = ["tenure", "MonthlyCharges", "TotalCharges"]
for column in data.columns:
    fill = train[column].median() if column in numeric else train[column].mode()[0]
    train[column] = train[column].fillna(fill)
    test[column] = test[column].fillna(fill)

for column in numeric:
    q1, q3 = train[column].quantile([0.25, 0.75])
    iqr = q3 - q1
    low, high = max(0, q1 - 1.5 * iqr), q3 + 1.5 * iqr
    print(column, "training outliers:", (~train[column].between(low, high)).sum())
    train[column] = train[column].clip(low, high)
    test[column] = test[column].clip(low, high)

for part in [train, test]:
    part["NewCustomer"] = (part["tenure"] <= 12).astype(int)

pd.concat([train, test]).sort_index().to_csv(folder + "Cleaned_Telecom_Customer_Churn.csv", index=False)
X_train = pd.get_dummies(train.drop(columns=["customerID", "Churn"]))
X_test = pd.get_dummies(test.drop(columns=["customerID", "Churn"]))
X_test = X_test.reindex(columns=X_train.columns, fill_value=0)
y_train, y_test = train["Churn"], test["Churn"]
scaler = StandardScaler()
X_train[numeric] = scaler.fit_transform(X_train[numeric])
X_test[numeric] = scaler.transform(X_test[numeric])
print("Prepared train/test shapes:", X_train.shape, X_test.shape)
print("Cleaned dataset saved in datasets folder.")

