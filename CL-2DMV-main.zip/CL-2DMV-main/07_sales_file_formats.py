
import pandas as pd
import matplotlib.pyplot as plt

folder = "C:/Users/rhutu/OneDrive/Desktop/DMV practicals/datasets/"

csv = pd.read_csv(folder + "sales_data_sample.csv", encoding="cp1252")
excel = pd.read_excel(folder + "sales.xlsx")
json = pd.read_json(folder + "sales.json")

other_orders = pd.concat([excel, json])["ORDERNUMBER"]
csv = csv[~csv["ORDERNUMBER"].isin(other_orders)]
data = pd.concat([csv[excel.columns], excel, json], ignore_index=True)
print(data.head())
data.info()
print("Missing values:\n", data.isna().sum())

data = data.drop_duplicates(subset=["ORDERNUMBER", "ORDERLINENUMBER"])
for column in ["COUNTRY", "PRODUCTLINE"]:
    data[column] = data[column].str.strip().fillna("Unknown")
data["SALES"] = pd.to_numeric(data["SALES"], errors="coerce")
data["ORDERDATE"] = pd.to_datetime(data["ORDERDATE"], errors="coerce")
data = data.dropna(subset=["ORDERDATE", "SALES"])
data = data[data["SALES"] > 0].copy()


data["Year"] = data["ORDERDATE"].dt.year
orders = data.groupby("ORDERNUMBER")["SALES"].sum()
print("Total sales:", round(data["SALES"].sum(), 2))
print("Average order value:", round(orders.mean(), 2))
print(data[["SALES", "QUANTITYORDERED"]].describe())
print("Sales by year:\n", data.groupby("Year")["SALES"].sum())

sales = data.groupby("PRODUCTLINE")["SALES"].sum()
sales.plot.bar(title="Sales by Product Category")
plt.xlabel("Product category")
plt.ylabel("Sales amount")
plt.tight_layout()
plt.show()

