import nltk
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
from nltk.stem import PorterStemmer

# Download required resources
nltk.download('punkt')
nltk.download('punkt_tab')
nltk.download('stopwords')

# Load text file
with open("input.txt", "r") as file:
    text = file.read()

# Tokenization
tokens = word_tokenize(text.lower())

print("Tokens:")
print(tokens)

# Stop-word removal
stop_words = set(stopwords.words('english'))

filtered_tokens = [
    word for word in tokens
    if word.isalpha() and word not in stop_words
]

print("\nAfter Stop-word Removal:")
print(filtered_tokens)

# Stemming
stemmer = PorterStemmer()

stemmed_tokens = [
    stemmer.stem(word)
    for word in filtered_tokens
]

print("\nStemmed Tokens:")
print(stemmed_tokens)
