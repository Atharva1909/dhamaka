# -----------------------------------------------
# Email Spam Filter using TF-IDF + Naive Bayes
# -----------------------------------------------

# Importing required libraries
from sklearn.feature_extraction.text import TfidfVectorizer   # Converts text into TF-IDF numerical features
from sklearn.naive_bayes import MultinomialNB                 # Naive Bayes algorithm for text classification
from sklearn.model_selection import train_test_split          # Splits data into training and testing sets
from sklearn.metrics import accuracy_score                    # To measure how accurate the model is
import numpy as np                                            # For numerical operations (optional here)

# Step 1: Create a small sample dataset
# Each sentence is an email message
# 1 = Spam, 0 = Not Spam
messages = [
    "Win money now", 
    "Limited offer free", 
    "Claim prize now",
    "Lunch meeting tomorrow", 
    "Project discussion today",
    "Let's catch up soon", 
    "Free entry to contest", 
    "Win a free ticket"
]

# Labels corresponding to each message
# 1 → Spam, 0 → Not Spam
labels = [1, 1, 1, 0, 0, 0, 1, 1]

# Step 2: Split data into training and testing sets
# test_size=0.25 → 25% of data for testing, 75% for training
# random_state=42 → ensures same random split every time
X_train, X_test, y_train, y_test = train_test_split(
    messages, labels, test_size=0.25, random_state=42
)

# Step 3: Convert text data into numerical features using TF-IDF
# TF-IDF → Term Frequency-Inverse Document Frequency
# It gives importance to words that are frequent in a message but rare overall
tfidf = TfidfVectorizer()           # Create a TF-IDF converter object
X_train_vec = tfidf.fit_transform(X_train)   # Learn vocabulary & transform training data
X_test_vec = tfidf.transform(X_test)         # Transform test data using same vocabulary

# Step 4: Train the Naive Bayes classifier
model = MultinomialNB()              # Create model object
model.fit(X_train_vec, y_train)      # Train model on training data

# Step 5: Evaluate the model on test data
pred = model.predict(X_test_vec)     # Predict spam or not spam for test data
print("Accuracy:", round(accuracy_score(y_test, pred), 2))   # Print model accuracy (0–1 scale)

# Step 6: Take user input and predict result
msg = input("\nEnter a message: ")            # Take new email message from user
msg_vec = tfidf.transform([msg])              # Convert it into TF-IDF vector
# Predict using trained model and display result
print("Result:", "🚨 Spam" if model.predict(msg_vec)[0] else "✅ Not Spam")
