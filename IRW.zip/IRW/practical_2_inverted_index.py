# Simple Inverted Index for Document Retrieval

# Step 1: Create a small collection of documents
docs = {
    1: "Heart disease prevention and healthy diet",
    2: "Spam emails contain phishing links",
    3: "Exercise reduces heart risk"
}

# Step 2: Build the inverted index
index = {}

for doc_id, text in docs.items():
    for word in text.lower().split():
        index.setdefault(word, set()).add(doc_id)

# Display the inverted index
print("Inverted Index:")
for word, doc_ids in index.items():
    print(word, ":", doc_ids)

# Step 3: Take a query from the user
query = input("\nEnter query: ").lower().split()

# Step 4: Find documents containing all query words
result = set(docs.keys())

for word in query:
    result &= index.get(word, set())

# Step 5: Print the result
print("\nDocuments found:", result)
