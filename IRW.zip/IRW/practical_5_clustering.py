# -------------------------------------------------------
# Simple Agglomerative Hierarchical Clustering Program
# -------------------------------------------------------

# Importing necessary libraries
from sklearn.datasets import load_iris                   # For loading the Iris dataset
from sklearn.cluster import AgglomerativeClustering      # For performing hierarchical clustering
from scipy.cluster.hierarchy import dendrogram, linkage  # For creating and plotting dendrogram
import matplotlib.pyplot as plt                          # For visualization

# Step 1: Load the dataset
iris = load_iris()                                       # Load the famous Iris dataset
X = iris.data[:, :2]                                     # Use only first 2 features (Sepal Length & Sepal Width) for 2D plotting

print("Dataset shape:", X.shape)                         # Display the shape of the dataset (number of samples and features)

# Step 2: Create a Dendrogram
# 'linkage' computes the hierarchical relationships between samples
linked = linkage(X, method='ward')                       # 'ward' minimizes variance when merging clusters
dendrogram(linked)                                       # Plot dendrogram to visualize merging steps
plt.title("Dendrogram")                                  # Set plot title
plt.xlabel("Samples")                                    # X-axis label
plt.ylabel("Distance")                                   # Y-axis label (represents dissimilarity)
plt.show()                                               # Display the dendrogram

# Step 3: Perform Agglomerative Clustering
cluster = AgglomerativeClustering(n_clusters=3, linkage='ward')  # Create clustering model with 3 clusters
labels = cluster.fit_predict(X)                                  # Fit model and get cluster labels for each data point

# Step 4: Plot clustered data points
plt.scatter(X[:, 0], X[:, 1], c=labels)                 # Scatter plot with color-coded clusters
plt.xlabel("Sepal Length")                              # X-axis label
plt.ylabel("Sepal Width")                               # Y-axis label
plt.title("Agglomerative Clustering Result")             # Add title to the plot
plt.show()                                               # Display the cluster plot

# Step 5: Print the assigned cluster labels
print("\nCluster Labels:", labels)                      # Show cluster label (0, 1, or 2) for each sample
