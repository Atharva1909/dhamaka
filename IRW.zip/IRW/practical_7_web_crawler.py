import os
import tempfile
import threading
import http.server
import functools
import requests
import pandas as pd
from bs4 import BeautifulSoup
from urllib.parse import urljoin

print("E-commerce Web Crawler")

# Create sample website
site = tempfile.mkdtemp()

# Sample products
names = ["Laptop", "Mobile", "Headphones",
         "Keyboard", "Mouse", "Monitor"]

products = []

# Create product pages
for i, name in enumerate(names, 1):
    price = i * 1000
    rating = (i % 5) + 1

    products.append((name, price, rating))

    with open(f"{site}/product{i}.html", "w") as f:
        f.write(
            f"<h1>{name}</h1>"
            f"<p class='price'>{price}</p>"
            f"<p class='rating'>{rating}</p>"
        )

# Create catalogue page
html = "<html><body><ul>"

for i, name in enumerate(names, 1):
    html += (
        f"<li class='product'>"
        f"<a href='product{i}.html'>{name}</a>"
        f"<p class='price'>{i * 1000}</p>"
        f"</li>"
    )

html += "</ul></body></html>"

with open(f"{site}/index.html", "w") as f:
    f.write(html)

# Start local web server
class Quiet(http.server.SimpleHTTPRequestHandler):
    def log_message(self, *args):
        pass

server = http.server.ThreadingHTTPServer(
    ("127.0.0.1", 0),
    functools.partial(Quiet, directory=site)
)

threading.Thread(
    target=server.serve_forever,
    daemon=True
).start()

base_url = f"http://127.0.0.1:{server.server_port}/"

# Create crawler
rows = []

try:
    # Read catalogue page
    response = requests.get(base_url + "index.html")
    soup = BeautifulSoup(response.text, "html.parser")

    # Extract product details
    for item in soup.select("li.product"):
        link = urljoin(base_url, item.a["href"])

        name = item.a.text
        price = item.select_one(".price").text

        # Visit product page to get rating
        page = requests.get(link)
        detail = BeautifulSoup(page.text, "html.parser")
        rating = detail.select_one(".rating").text

        rows.append([name, price, rating, link])

    # Display and save results
    df = pd.DataFrame(
        rows,
        columns=["Name", "Price", "Rating", "Link"]
    )

    print(df)
    df.to_csv("products.csv", index=False)

    print("\nProducts saved to products.csv")

finally:
    server.shutdown()
