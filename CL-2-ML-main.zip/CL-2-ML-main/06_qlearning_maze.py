"""Assignment 6A: Learn a maze path using tabular Q-learning.
Run: python 06_qlearning_maze.py
"""

import random
import numpy as np

# 0 = free cell, 1 = wall. Coordinates are (row, column), starting from 0.
maze = np.array([
    [0, 0, 0, 1, 0],
    [1, 1, 0, 1, 0],
    [0, 0, 0, 0, 0],
    [0, 1, 1, 1, 0],
    [0, 0, 0, 0, 0],
])
start, goal = (0, 0), (4, 4)
moves = [(-1, 0), (1, 0), (0, -1), (0, 1)]  # Up, Down, Left, Right
symbols = ["^", "v", "<", ">"]
q = np.zeros((*maze.shape, 4))  # q[row, column, action]
rng = random.Random(7)
# alpha: learning rate; gamma: value of future rewards.
# epsilon: probability of trying a random move.
alpha, gamma, epsilon = 0.5, 0.9, 1.0
episodes, max_steps = 1000, 100


def next_state(state, action):
    dr, dc = moves[action]
    return state[0] + dr, state[1] + dc


def valid_actions(state):
    actions = []
    for action in range(4):
        row, col = next_state(state, action)
        if 0 <= row < maze.shape[0] and 0 <= col < maze.shape[1]:
            if maze[row, col] == 0:
                actions.append(action)
    return actions


def choose_action(state, exploration):
    actions = valid_actions(state)
    if not actions:
        raise ValueError(f"No valid move from {state}; check the maze.")
    if rng.random() < exploration:
        return rng.choice(actions)  # Explore: try a random valid action.
    return max(actions, key=lambda action: q[state][action])  # Exploit.


# Training: update one Q value after every move.
successes = 0
for episode in range(episodes):
    state = start
    for step in range(max_steps):
        action = choose_action(state, epsilon)
        new_state = next_state(state, action)
        reward = 100 if new_state == goal else -1
        if new_state == goal:
            target = reward  # Terminal goal: no future reward to add.
        else:
            future = max(q[new_state][a] for a in valid_actions(new_state))
            target = reward + gamma * future
        q[state][action] += alpha * (target - q[state][action])
        state = new_state
        if state == goal:
            successes += 1
            break
    epsilon = max(0.05, epsilon * 0.995)

# Testing: follow the learned greedy policy, with no random exploration.
state, path = start, [start]
for step in range(max_steps):
    state = next_state(state, choose_action(state, 0))
    if state in path:
        raise RuntimeError("Learned policy loops; train longer or check the maze.")
    path.append(state)
    if state == goal:
        break
if state != goal:
    raise RuntimeError("Goal not reached within the testing step limit.")

print(f"Training episodes reaching goal: {successes}/{episodes}")
print("Learned path:", " -> ".join(map(str, path)))
print("Number of moves:", len(path) - 1)
print("\nMaze with learned path: S=start, G=goal, #=wall, *=path")
for row in range(maze.shape[0]):
    cells = []
    for col in range(maze.shape[1]):
        cell = (row, col)
        mark = "#" if maze[cell] else "."
        if cell in path:
            mark = "*"
        if cell == start:
            mark = "S"
        if cell == goal:
            mark = "G"
        cells.append(mark)
    print(" ".join(cells))
