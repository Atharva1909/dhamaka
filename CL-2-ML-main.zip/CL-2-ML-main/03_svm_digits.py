import matplotlib.pyplot as plt
from sklearn.datasets import load_digits
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC
from sklearn.metrics import accuracy_score

# Load digit images and split them into training and testing data.
digits = load_digits()
X_train, X_test, y_train, y_test = train_test_split(
    digits.data, digits.target, test_size=0.2, random_state=42, stratify=digits.target)

# Scale the pixels and train the SVM.
scaler = StandardScaler()
model = SVC(kernel="rbf")
model.fit(scaler.fit_transform(X_train), y_train)
prediction = model.predict(scaler.transform(X_test))
print("Accuracy:", accuracy_score(y_test, prediction))

# Display one test image with its actual and predicted digit.
plt.imshow(X_test[0].reshape(8, 8), cmap="gray_r")
plt.title(f"Actual: {y_test[0]}, Predicted: {prediction[0]}")
plt.axis("off")
plt.show()
