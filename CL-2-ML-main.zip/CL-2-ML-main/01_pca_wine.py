import pandas as pd
import matplotlib.pyplot as plt
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA

# 1. Load the dataset. Keep the class labels separate.
data = pd.read_csv("C:/Users/rhutu/Downloads/Wine.csv")
X = data.drop(columns=["Customer_Segment"])
y = data["Customer_Segment"]

# 2. Scale the features so larger units do not dominate PCA.
X_scaled = StandardScaler().fit_transform(X)

# 3. Reduce the 13 features to 2 principal components.
pca = PCA(n_components=2)
X_pca = pca.fit_transform(X_scaled)

print("Original shape:", X.shape)
print("Reduced shape:", X_pca.shape)
print("Variance ratio of each component:", pca.explained_variance_ratio_)
print("Total variance retained:", pca.explained_variance_ratio_.sum())
print("First 5 transformed rows:\n", X_pca[:5])

# 4. Find how many components retain at least 95% of the variance.
pca95 = PCA(n_components=0.95)
pca95.fit(X_scaled)
print("Components needed for 95% variance:", pca95.n_components_)

# 5. Plot the two components. Labels are used only for colouring.
for label in sorted(y.unique()):
    plt.scatter(X_pca[y == label, 0], X_pca[y == label, 1], label=f"Class {label}")

plt.xlabel("Principal Component 1")
plt.ylabel("Principal Component 2")
plt.title("PCA on Wine Dataset")
plt.legend()
plt.show()

