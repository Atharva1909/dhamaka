import pandas as pd
import matplotlib.pyplot as plt
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans

# Use measurements only; Id and Species are not clustering inputs.
data = pd.read_csv("C:/Users/rhutu/Downloads/Iris.csv")
features = ["SepalLengthCm", "SepalWidthCm", "PetalLengthCm", "PetalWidthCm"]
X = data[features]
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# WCSS measures how spread out the points are inside clusters.
wcss = []
for k in range(1, 11):
    model = KMeans(n_clusters=k, n_init=10, random_state=42)
    model.fit(X_scaled)
    wcss.append(model.inertia_)

plt.plot(range(1, 11), wcss, marker="o")
plt.xlabel("Number of clusters")
plt.ylabel("WCSS")
plt.title("Elbow Method")
plt.show()

# Choose 3 clusters after inspecting the elbow plot.
# The elbow is a visual guide, not proof of a unique best value.
model = KMeans(n_clusters=3, n_init=10, random_state=42)
labels = model.fit_predict(X_scaled)
centers = scaler.inverse_transform(model.cluster_centers_)
print("Cluster sizes:")
print(pd.Series(labels).value_counts().sort_index())
print("Cluster centers in original units:")
print(pd.DataFrame(centers, columns=features).round(2))

# Clustering uses all four features; plot only the two petal features.
for cluster in range(3):
    rows = labels == cluster
    plt.scatter(X.loc[rows, "PetalLengthCm"], X.loc[rows, "PetalWidthCm"],
                label=f"Cluster {cluster}")
plt.scatter(centers[:, 2], centers[:, 3], c="black", marker="X", s=150, label="Centers")
plt.xlabel("Petal length (cm)")
plt.ylabel("Petal width (cm)")
plt.title("K-Means on Iris")
plt.legend()
plt.show()
