import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LinearRegression, Ridge, Lasso
from sklearn.metrics import r2_score, mean_squared_error, mean_absolute_error

# Load only the columns needed for prediction.
columns = ["fare_amount", "pickup_datetime", "pickup_longitude",
           "pickup_latitude", "dropoff_longitude", "dropoff_latitude",
           "passenger_count"]
data = pd.read_csv("C:/Users/rhutu/Downloads/uber.csv", usecols=columns)

# Remove duplicates, missing values and invalid trips.
data = data.drop_duplicates()
for column in columns:
    if column != "pickup_datetime":
        data[column] = pd.to_numeric(data[column], errors="coerce")
data["pickup_datetime"] = pd.to_datetime(data["pickup_datetime"], errors="coerce", utc=True)
data = data.replace([np.inf, -np.inf], np.nan).dropna()
# These coordinates cover the New York area in this dataset.
data = data[(data["fare_amount"] > 0)
            & data["passenger_count"].between(1, 6)
            & (data["passenger_count"] % 1 == 0)
            & data["pickup_longitude"].between(-75, -72)
            & data["dropoff_longitude"].between(-75, -72)
            & data["pickup_latitude"].between(40, 42)
            & data["dropoff_latitude"].between(40, 42)].copy()

# Haversine formula: estimate straight-line distance over the Earth.
def distance_km(lon1, lat1, lon2, lat2):
    lon1, lat1, lon2, lat2 = np.radians([lon1, lat1, lon2, lat2])
    a = (np.sin((lat2 - lat1) / 2) ** 2
         + np.cos(lat1) * np.cos(lat2) * np.sin((lon2 - lon1) / 2) ** 2)
    return 6371 * 2 * np.arcsin(np.sqrt(np.clip(a, 0, 1)))
data["distance_km"] = distance_km(data["pickup_longitude"], data["pickup_latitude"],
                                  data["dropoff_longitude"], data["dropoff_latitude"])
data = data[data["distance_km"] > 0].copy()
data["hour"] = data["pickup_datetime"].dt.hour
data["weekday"] = data["pickup_datetime"].dt.dayofweek
data["month"] = data["pickup_datetime"].dt.month
data["year"] = data["pickup_datetime"].dt.year

# Use 80% of trips for training and 20% for testing.
train, test = train_test_split(data, test_size=0.2, random_state=42)
train[["fare_amount", "distance_km"]].plot.box(subplots=True, figsize=(8, 4))
plt.show()

# Remove IQR outliers from training data only.
keep = pd.Series(True, index=train.index)
for column in ["fare_amount", "distance_km"]:
    q1, q3 = train[column].quantile([0.25, 0.75])
    iqr = q3 - q1
    valid = train[column].between(q1 - 1.5 * iqr, q3 + 1.5 * iqr)
    print(column, "training outliers:", (~valid).sum())
    keep = keep & valid
train = train[keep]

features = ["distance_km", "passenger_count", "hour", "weekday", "month", "year"]

# Correlation shows how strongly pairs of variables move together.
correlation = train[features + ["fare_amount"]].corr()
print(correlation.round(2))

X_train, y_train = train[features], train["fare_amount"]
X_test, y_test = test[features], test["fare_amount"]

# Learn scaling from training data, then apply it to both sets.
scaler = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_test = scaler.transform(X_test)

# Train and compare all three models on the same test data.
models = {"Linear": LinearRegression(),
          "Ridge": Ridge(alpha=1),
          "Lasso": Lasso(alpha=0.01, max_iter=10000)}
results = []
for name, model in models.items():
    model.fit(X_train, y_train)
    prediction = model.predict(X_test)
    results.append([name, r2_score(y_test, prediction),
                    np.sqrt(mean_squared_error(y_test, prediction)),
                    mean_absolute_error(y_test, prediction)])
print(pd.DataFrame(results, columns=["Model", "R2", "RMSE", "MAE"]).round(4).to_string(index=False))
