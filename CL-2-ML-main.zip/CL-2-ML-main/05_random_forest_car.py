import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import OneHotEncoder
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, classification_report, ConfusionMatrixDisplay

# The supplied CSV has no header row.
columns = ["buying", "maint", "doors", "persons", "lug_boot", "safety", "class"]
data = pd.read_csv("C:/Users/rhutu/Downloads/car_evaluation.csv",
                   header=None, names=columns, dtype=str)
X = data.drop(columns=["class"])
y = data["class"]

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y)

# Convert categories into binary columns, learning from training data only.
encoder = OneHotEncoder(handle_unknown="ignore")
X_train = encoder.fit_transform(X_train)
X_test = encoder.transform(X_test)

# A Random Forest combines predictions from many decision trees.
model = RandomForestClassifier(n_estimators=100, random_state=42)
model.fit(X_train, y_train)
prediction = model.predict(X_test)
labels = ["unacc", "acc", "good", "vgood"]
print("Accuracy:", accuracy_score(y_test, prediction))
print(classification_report(y_test, prediction, labels=labels, zero_division=0))

# Predict acceptability for one new car.
new_car = pd.DataFrame([["low", "low", "4", "4", "big", "high"]], columns=columns[:-1])
print("New car prediction:", model.predict(encoder.transform(new_car))[0])

ConfusionMatrixDisplay.from_predictions(y_test, prediction, labels=labels, cmap="Blues")
plt.title("Random Forest: Car Acceptability")
plt.tight_layout()
plt.show()
